# building lenet5 from scratch with numpy

|-main.py

|-data_process

|	util.py

|-net

|	layer.py

|	model.py

|-mnist_data

|	t10k-images.idx3-ubyte

|	t10k-labels.idx1-ubyte

|	train-images.idx3-ubyte

|	train-labels.idx1-ubyte

requirements: please refer `report.md`

minist dataset should be uncompressed into folder `minist_data`
